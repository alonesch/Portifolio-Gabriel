function Footer() {
    return (
      <footer className="site-footer">
      Powered by <a href="https://www.instagram.com/alone.lineess/" target="_blank"
          rel="noopener noreferrer">alone</a>
  </footer>
    );
}

export default Footer