function Gallery() {
    return (
        <section className="gallery">
            <img src="/corte_1.jpeg" alt="Corte 1" />
            <img src="/corte_2.jpeg" alt="Corte 2" />
            <img src="/corte_3.jpeg" alt="Corte 3" />
            <img src="/corte_4.jpeg" alt="Corte 4" />
            {/* <img src="/corte_5.jpeg" alt="Corte 5" /> */}
            <img src="/corte_6.jpeg" alt="Corte 6" />
            <img src="/corte_7.jpeg" alt="Corte 7" />
            <img src="/corte_8.jpeg" alt="Corte 8" />
            <img src="/corte_9.jpeg" alt="Corte 9" />
           
        



        </section>
    );
}
export default Gallery;
